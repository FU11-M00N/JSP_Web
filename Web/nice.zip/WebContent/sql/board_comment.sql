create table board_comment(
	board_nick varchar(50),
	board_content varchar(1000),
	reg_date datetime,
	ref int,
	re_step int,
	re_level int,
	board_num varchar(30)
);